package com.sfu.register;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sfu.databases.ListingDao;
import com.sfu.databases.UserDao;
import com.sfu.exception.DatabaseInsertException;
import com.sfu.object.Listing;
import com.sfu.object.User;
import com.sfu.request.HttpClient;

import com.google.gson.Gson;
import java.lang.reflect.Type;
import com.google.gson.reflect.TypeToken;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String target = "/home.jsp";
		
		String name = request.getParameter("name");
		request.getSession().setAttribute("user", name);
		
		String type = request.getParameter("type");
		
		//System.out.println(name);
		System.out.println("The type Value is: ");
		System.out.println(type);
		
		
		List<Listing> results = new ArrayList<Listing>();		
		
		
		HttpClient obj = new HttpClient();
		
		try {
        	System.out.println("Testing 1 - Send Http GET request");
			String result = obj.sendGet("1");
			//System.out.println(result);
			
			Gson gson = new Gson();
			Type listType = new TypeToken<ArrayList<String>>(){}.getType();
			List<String> zipIdList = new Gson().fromJson(result, listType);			
			System.out.println(zipIdList);
			
			List<Listing> listingList = ListingDao.getListingsByZipIds(zipIdList);
			//System.out.println(listingList.toString());
			
			List<Listing> allListings = ListingDao.getFourtyListings();
			
			
			results.addAll(listingList);
			results.addAll(allListings);
			
			String listingListJson = gson.toJson(listingList);
			System.out.println(listingListJson);
			
			request.setAttribute("listingList", listingListJson);
			request.setAttribute("listingListJ", results);
				
			//System.out.println("Testing 2 - Send Http POST request");
            //obj.sendPost();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			obj.close();
		}
		
		//List<Listing> listings = ListingDao.getAllListings();
		//System.out.println(email);
		//System.out.println(password);		
		
				
		request.setAttribute("user", name);	
		//List<Listing> listings = ListingDao.getAllDistinctClients();
		
		//request.getSession().val
		
		
		RequestDispatcher view = request.getRequestDispatcher(target);
		view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
