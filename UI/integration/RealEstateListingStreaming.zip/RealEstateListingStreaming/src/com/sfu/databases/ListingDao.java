package com.sfu.databases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.sfu.logger.ActivityLogger;
import com.sfu.object.Listing;


public class ListingDao {
	public static List<Listing> getAllListings() {
		String sql = "SELECT DISTINCT * FROM austinhousingdata;";

		Connection connection = null;
		
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		List<Listing> listingList = new ArrayList<Listing>();

		try {
			
			connection = DatabaseHelper.connectToLocalDatabase();
			preparedStatement = connection.prepareStatement(sql);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				Listing tempListing = new Listing();				
				
				
				int zipId = resultSet.getInt("zpid");
				int zipcode = resultSet.getInt("zipcode");
				double latitude = resultSet.getDouble("latitude");
				double longitude = resultSet.getDouble("longitude");
				double propertyTaxRate = resultSet.getDouble("propertyTaxRate");
				int garageSpaces = resultSet.getInt("garageSpaces");
				int parkingSpaces = resultSet.getInt("parkingSpaces");
				int yearBuilt = resultSet.getInt("yearBuilt");
				double latestPrice = resultSet.getDouble("latestPrice");
				int numPriceChanges = resultSet.getInt("numPriceChanges");
				int latest_salemonth = resultSet.getInt("latest_salemonth");
				int latest_saleyear = resultSet.getInt("latest_saleyear");
				int numOfPhotos = resultSet.getInt("numOfPhotos");
				int numOfAccessibilityFeatures = resultSet.getInt("numOfAccessibilityFeatures");
				int numOfAppliances = resultSet.getInt("numOfAppliances");
				int numOfParkingFeatures = resultSet.getInt("numOfParkingFeatures");
				int numOfPatioAndPorchFeatures = resultSet.getInt("numOfPatioAndPorchFeatures");
				int numOfSecurityFeatures = resultSet.getInt("numOfSecurityFeatures");
				int numOfWaterfrontFeatures= resultSet.getInt("numOfWaterfrontFeatures") ;
				int numOfWindowFeatures = resultSet.getInt("numOfWindowFeatures");
				int numOfCommunityFeatures = resultSet.getInt("numOfCommunityFeatures");
				double lotSizeSqFt = resultSet.getDouble("lotSizeSqFt");
				double livingAreaSqFt = resultSet.getDouble("livingAreaSqFt");
				int numOfPrimarySchools = resultSet.getInt("numOfPrimarySchools");
				int numOfElementarySchools = resultSet.getInt("numOfElementarySchools");
				int numOfMiddleSchools = resultSet.getInt("numOfMiddleSchools");
				int numOfHighSchools = resultSet.getInt("numOfHighSchools");
				double avgSchoolDistance= resultSet.getDouble("avgSchoolDistance");
				double avgSchoolRating = resultSet.getDouble("avgSchoolRating");
				int avgSchoolSize = resultSet.getInt("avgSchoolSize");
				int MedianStudentsPerTeacher = resultSet.getInt("MedianStudentsPerTeacher");
				double numOfBathrooms = resultSet.getDouble("numOfBathrooms");
				int numOfBedrooms = resultSet.getInt("numOfBedrooms");
				int numOfStories = resultSet.getInt("numOfStories");
				String city = resultSet.getString("city");;
				String streetAddress = resultSet.getString("streetAddress");				
				String hasAssociation = resultSet.getString("hasAssociation");
				String hasCooling = resultSet.getString("hasCooling");
				String hasGarage = resultSet.getString("hasGarage");
				String hasHeating = resultSet.getString("hasHeating");
				String hasSpa = resultSet.getString("hasSpa");
				String hasView = resultSet.getString("hasView");	
				String homeType = resultSet.getString("homeType");
				String latestSaledate = resultSet.getString("latest_saledate");
				String latestPriceSource = resultSet.getString("latestPriceSource");
				//String homeImage = resultSet.getString("homeImage");
				
				//tempListing.setHomeImage(homeImage);
				tempListing.setCity(city);
				tempListing.setLatestPriceSource(latestPriceSource);
				tempListing.setLatestSaledate(latestSaledate);
				tempListing.setHomeType(homeType);
				tempListing.setHasView(hasView);
				tempListing.setHasSpa(hasSpa);
				tempListing.setHasHeating(hasHeating);
				tempListing.setHasGarage(hasGarage);
				tempListing.setHasCooling(hasCooling);
				tempListing.setHasAssociation(hasAssociation);				
				tempListing.setStreetAddress(streetAddress);
				tempListing.setAvgschooldistance(avgSchoolDistance);
				tempListing.setAvgschoolrating(avgSchoolRating);
				tempListing.setAvgschoolsize(avgSchoolSize);
				tempListing.setGaragespaces(garageSpaces);
				tempListing.setLatest_salemonth(latest_salemonth);
				tempListing.setLatest_saleyear(latest_saleyear);
				tempListing.setLatestprice(latestPrice);
				tempListing.setLatitude(latitude);
				tempListing.setLivingareasqft(livingAreaSqFt);
				tempListing.setLongitude(longitude);
				tempListing.setLotsizesqft(lotSizeSqFt);
				tempListing.setMedianstudentsperteacher(MedianStudentsPerTeacher);
				tempListing.setNumofaccessibilityfeatures(numOfAccessibilityFeatures);
				tempListing.setNumofappliances(numOfAppliances);
				tempListing.setNumofbathrooms(numOfBathrooms);
				tempListing.setNumofbedrooms(numOfBedrooms);
				tempListing.setNumofcommunityfeatures(numOfCommunityFeatures);
				tempListing.setNumofelementaryschools(numOfElementarySchools);
				tempListing.setNumofhighschools(numOfHighSchools);
				tempListing.setNumofmiddleschools(numOfMiddleSchools);
				tempListing.setNumofparkingfeatures(numOfParkingFeatures);
				tempListing.setNumofpatioandporchfeatures(numOfPatioAndPorchFeatures);
				tempListing.setNumofphotos(numOfPhotos);
				tempListing.setNumofprimaryschools(numOfPrimarySchools);
				tempListing.setNumofsecurityfeatures(numOfSecurityFeatures);
				tempListing.setNumofstories(numOfStories);
				tempListing.setNumofwaterfrontfeatures(numOfWaterfrontFeatures);
				tempListing.setNumofwindowfeatures(numOfWindowFeatures);
				tempListing.setNumpricechanges(numPriceChanges);
				tempListing.setParkingspaces(parkingSpaces);
				tempListing.setPropertytaxrate(propertyTaxRate);
				tempListing.setYearbuilt(yearBuilt);
				tempListing.setZipcode(zipcode);
				tempListing.setZipId(zipId);
				
			
				
				listingList.add(tempListing);
			}
		} catch (SQLException e) {
			System.out.println("Issue with getAllClients");
			//ActivityLogger.debug("ClientDao: getAllClients", "Connection is Null "  + e.getMessage());
			//System.out.println(e);

		} finally {
			DatabaseHelper.closeQuietly(preparedStatement);
			DatabaseHelper.closeQuietly(connection);
			
		}
		
		return listingList;
	}
	
	public static List<Listing> getFourtyListings() {
		String sql = "SELECT DISTINCT * FROM austinhousingdata LIMIT 40;";

		Connection connection = null;
		Random rn = new Random();
		
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		List<Listing> listingList = new ArrayList<Listing>();

		try {
			
			connection = DatabaseHelper.connectToLocalDatabase();
			preparedStatement = connection.prepareStatement(sql);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				Listing tempListing = new Listing();				
				
				
				int zipId = resultSet.getInt("zpid");
				int zipcode = resultSet.getInt("zipcode");
				double latitude = resultSet.getDouble("latitude");
				double longitude = resultSet.getDouble("longitude");
				double propertyTaxRate = resultSet.getDouble("propertyTaxRate");
				int garageSpaces = resultSet.getInt("garageSpaces");
				int parkingSpaces = resultSet.getInt("parkingSpaces");
				int yearBuilt = resultSet.getInt("yearBuilt");
				double latestPrice = resultSet.getDouble("latestPrice");
				int numPriceChanges = resultSet.getInt("numPriceChanges");
				int latest_salemonth = resultSet.getInt("latest_salemonth");
				int latest_saleyear = resultSet.getInt("latest_saleyear");
				int numOfPhotos = resultSet.getInt("numOfPhotos");
				int numOfAccessibilityFeatures = resultSet.getInt("numOfAccessibilityFeatures");
				int numOfAppliances = resultSet.getInt("numOfAppliances");
				int numOfParkingFeatures = resultSet.getInt("numOfParkingFeatures");
				int numOfPatioAndPorchFeatures = resultSet.getInt("numOfPatioAndPorchFeatures");
				int numOfSecurityFeatures = resultSet.getInt("numOfSecurityFeatures");
				int numOfWaterfrontFeatures= resultSet.getInt("numOfWaterfrontFeatures") ;
				int numOfWindowFeatures = resultSet.getInt("numOfWindowFeatures");
				int numOfCommunityFeatures = resultSet.getInt("numOfCommunityFeatures");
				double lotSizeSqFt = resultSet.getDouble("lotSizeSqFt");
				double livingAreaSqFt = resultSet.getDouble("livingAreaSqFt");
				int numOfPrimarySchools = resultSet.getInt("numOfPrimarySchools");
				int numOfElementarySchools = resultSet.getInt("numOfElementarySchools");
				int numOfMiddleSchools = resultSet.getInt("numOfMiddleSchools");
				int numOfHighSchools = resultSet.getInt("numOfHighSchools");
				double avgSchoolDistance= resultSet.getDouble("avgSchoolDistance");
				double avgSchoolRating = resultSet.getDouble("avgSchoolRating");
				int avgSchoolSize = resultSet.getInt("avgSchoolSize");
				int MedianStudentsPerTeacher = resultSet.getInt("MedianStudentsPerTeacher");
				double numOfBathrooms = resultSet.getDouble("numOfBathrooms");
				int numOfBedrooms = resultSet.getInt("numOfBedrooms");
				int numOfStories = resultSet.getInt("numOfStories");
				String city = resultSet.getString("city");;
				String streetAddress = resultSet.getString("streetAddress");				
				String hasAssociation = resultSet.getString("hasAssociation");
				String hasCooling = resultSet.getString("hasCooling");
				String hasGarage = resultSet.getString("hasGarage");
				String hasHeating = resultSet.getString("hasHeating");
				String hasSpa = resultSet.getString("hasSpa");
				String hasView = resultSet.getString("hasView");	
				String homeType = resultSet.getString("homeType");
				String latestSaledate = resultSet.getString("latest_saledate");
				String latestPriceSource = resultSet.getString("latestPriceSource");
				//String homeImage = resultSet.getString("homeImage");
				
				//tempListing.setHomeImage(homeImage);
				tempListing.setCity(city);
				tempListing.setLatestPriceSource(latestPriceSource);
				tempListing.setLatestSaledate(latestSaledate);
				tempListing.setHomeType(homeType);
				tempListing.setHasView(hasView);
				tempListing.setHasSpa(hasSpa);
				tempListing.setHasHeating(hasHeating);
				tempListing.setHasGarage(hasGarage);
				tempListing.setHasCooling(hasCooling);
				tempListing.setHasAssociation(hasAssociation);				
				tempListing.setStreetAddress(streetAddress);
				tempListing.setAvgschooldistance(avgSchoolDistance);
				tempListing.setAvgschoolrating(avgSchoolRating);
				tempListing.setAvgschoolsize(avgSchoolSize);
				tempListing.setGaragespaces(garageSpaces);
				tempListing.setLatest_salemonth(latest_salemonth);
				tempListing.setLatest_saleyear(latest_saleyear);
				tempListing.setLatestprice(latestPrice);
				tempListing.setLatitude(latitude);
				tempListing.setLivingareasqft(livingAreaSqFt);
				tempListing.setLongitude(longitude);
				tempListing.setLotsizesqft(lotSizeSqFt);
				tempListing.setMedianstudentsperteacher(MedianStudentsPerTeacher);
				tempListing.setNumofaccessibilityfeatures(numOfAccessibilityFeatures);
				tempListing.setNumofappliances(numOfAppliances);
				tempListing.setNumofbathrooms(numOfBathrooms);
				tempListing.setNumofbedrooms(numOfBedrooms);
				tempListing.setNumofcommunityfeatures(numOfCommunityFeatures);
				tempListing.setNumofelementaryschools(numOfElementarySchools);
				tempListing.setNumofhighschools(numOfHighSchools);
				tempListing.setNumofmiddleschools(numOfMiddleSchools);
				tempListing.setNumofparkingfeatures(numOfParkingFeatures);
				tempListing.setNumofpatioandporchfeatures(numOfPatioAndPorchFeatures);
				tempListing.setNumofphotos(numOfPhotos);
				tempListing.setNumofprimaryschools(numOfPrimarySchools);
				tempListing.setNumofsecurityfeatures(numOfSecurityFeatures);
				tempListing.setNumofstories(numOfStories);
				tempListing.setNumofwaterfrontfeatures(numOfWaterfrontFeatures);
				tempListing.setNumofwindowfeatures(numOfWindowFeatures);
				tempListing.setNumpricechanges(numPriceChanges);
				tempListing.setParkingspaces(parkingSpaces);
				tempListing.setPropertytaxrate(propertyTaxRate);
				tempListing.setYearbuilt(yearBuilt);
				tempListing.setZipcode(zipcode);
				tempListing.setZipId(zipId);
				
				Integer imageNumber = 0;
				String image = "assets/img/demo/property-";
				imageNumber = rn.nextInt(6 - 1 + 1) + 1;
				image = image + imageNumber.toString() + ".jpg";
				tempListing.setImage(image);
				
			
				
				listingList.add(tempListing);
			}
		} catch (SQLException e) {
			System.out.println("Issue with getAllClients");
			//ActivityLogger.debug("ClientDao: getAllClients", "Connection is Null "  + e.getMessage());
			//System.out.println(e);

		} finally {
			DatabaseHelper.closeQuietly(preparedStatement);
			DatabaseHelper.closeQuietly(connection);
			
		}
		
		return listingList;
	}
	
	public static List<Listing> getListingsByZipIds(List<String> zipIds) {
		List<Listing> listingList = new ArrayList<Listing>();
		Random rn = new Random();
		Integer imageNumber = 0;
		String image = "assets/img/demo/property-";
		
		for (String tenpZipId : zipIds) {
			int zipId = Integer.parseInt(tenpZipId);
			Listing tempListing = ListingDao.getListingsByZipId(zipId);
			
			imageNumber = rn.nextInt(6 - 1 + 1) + 1;
			image = image + imageNumber.toString() + ".jpg";
			tempListing.setImage(image);
			
			listingList.add(tempListing);
			
			image = "assets/img/demo/property-";
			
		}
		return listingList;
	}
	
	public static Listing getListingsByZipId(int zipId) {
		String sql = "SELECT DISTINCT * FROM austinhousingdata WHERE zpid = ?;";

		Connection connection = null;
		
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		Listing tempListing = new Listing();

		try {
			
			connection = DatabaseHelper.connectToLocalDatabase();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setInt(1, zipId);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
								
				
				
				//int zipId = resultSet.getInt("zpid");
				int zipcode = resultSet.getInt("zipcode");
				double latitude = resultSet.getDouble("latitude");
				double longitude = resultSet.getDouble("longitude");
				double propertyTaxRate = resultSet.getDouble("propertyTaxRate");
				int garageSpaces = resultSet.getInt("garageSpaces");
				int parkingSpaces = resultSet.getInt("parkingSpaces");
				int yearBuilt = resultSet.getInt("yearBuilt");
				double latestPrice = resultSet.getDouble("latestPrice");
				int numPriceChanges = resultSet.getInt("numPriceChanges");
				int latest_salemonth = resultSet.getInt("latest_salemonth");
				int latest_saleyear = resultSet.getInt("latest_saleyear");
				int numOfPhotos = resultSet.getInt("numOfPhotos");
				int numOfAccessibilityFeatures = resultSet.getInt("numOfAccessibilityFeatures");
				int numOfAppliances = resultSet.getInt("numOfAppliances");
				int numOfParkingFeatures = resultSet.getInt("numOfParkingFeatures");
				int numOfPatioAndPorchFeatures = resultSet.getInt("numOfPatioAndPorchFeatures");
				int numOfSecurityFeatures = resultSet.getInt("numOfSecurityFeatures");
				int numOfWaterfrontFeatures= resultSet.getInt("numOfWaterfrontFeatures") ;
				int numOfWindowFeatures = resultSet.getInt("numOfWindowFeatures");
				int numOfCommunityFeatures = resultSet.getInt("numOfCommunityFeatures");
				double lotSizeSqFt = resultSet.getDouble("lotSizeSqFt");
				double livingAreaSqFt = resultSet.getDouble("livingAreaSqFt");
				int numOfPrimarySchools = resultSet.getInt("numOfPrimarySchools");
				int numOfElementarySchools = resultSet.getInt("numOfElementarySchools");
				int numOfMiddleSchools = resultSet.getInt("numOfMiddleSchools");
				int numOfHighSchools = resultSet.getInt("numOfHighSchools");
				double avgSchoolDistance= resultSet.getDouble("avgSchoolDistance");
				double avgSchoolRating = resultSet.getDouble("avgSchoolRating");
				int avgSchoolSize = resultSet.getInt("avgSchoolSize");
				int MedianStudentsPerTeacher = resultSet.getInt("MedianStudentsPerTeacher");
				double numOfBathrooms = resultSet.getDouble("numOfBathrooms");
				int numOfBedrooms = resultSet.getInt("numOfBedrooms");
				int numOfStories = resultSet.getInt("numOfStories");
				String city = resultSet.getString("city");;
				String streetAddress = resultSet.getString("streetAddress");				
				String hasAssociation = resultSet.getString("hasAssociation");
				String hasCooling = resultSet.getString("hasCooling");
				String hasGarage = resultSet.getString("hasGarage");
				String hasHeating = resultSet.getString("hasHeating");
				String hasSpa = resultSet.getString("hasSpa");
				String hasView = resultSet.getString("hasView");	
				String homeType = resultSet.getString("homeType");
				String latestSaledate = resultSet.getString("latest_saledate");
				String latestPriceSource = resultSet.getString("latestPriceSource");
				//String homeImage = resultSet.getString("homeImage");
				
				//tempListing.setHomeImage(homeImage);
				tempListing.setCity(city);
				tempListing.setLatestPriceSource(latestPriceSource);
				tempListing.setLatestSaledate(latestSaledate);
				tempListing.setHomeType(homeType);
				tempListing.setHasView(hasView);
				tempListing.setHasSpa(hasSpa);
				tempListing.setHasHeating(hasHeating);
				tempListing.setHasGarage(hasGarage);
				tempListing.setHasCooling(hasCooling);
				tempListing.setHasAssociation(hasAssociation);				
				tempListing.setStreetAddress(streetAddress);
				tempListing.setAvgschooldistance(avgSchoolDistance);
				tempListing.setAvgschoolrating(avgSchoolRating);
				tempListing.setAvgschoolsize(avgSchoolSize);
				tempListing.setGaragespaces(garageSpaces);
				tempListing.setLatest_salemonth(latest_salemonth);
				tempListing.setLatest_saleyear(latest_saleyear);
				tempListing.setLatestprice(latestPrice);
				tempListing.setLatitude(latitude);
				tempListing.setLivingareasqft(livingAreaSqFt);
				tempListing.setLongitude(longitude);
				tempListing.setLotsizesqft(lotSizeSqFt);
				tempListing.setMedianstudentsperteacher(MedianStudentsPerTeacher);
				tempListing.setNumofaccessibilityfeatures(numOfAccessibilityFeatures);
				tempListing.setNumofappliances(numOfAppliances);
				tempListing.setNumofbathrooms(numOfBathrooms);
				tempListing.setNumofbedrooms(numOfBedrooms);
				tempListing.setNumofcommunityfeatures(numOfCommunityFeatures);
				tempListing.setNumofelementaryschools(numOfElementarySchools);
				tempListing.setNumofhighschools(numOfHighSchools);
				tempListing.setNumofmiddleschools(numOfMiddleSchools);
				tempListing.setNumofparkingfeatures(numOfParkingFeatures);
				tempListing.setNumofpatioandporchfeatures(numOfPatioAndPorchFeatures);
				tempListing.setNumofphotos(numOfPhotos);
				tempListing.setNumofprimaryschools(numOfPrimarySchools);
				tempListing.setNumofsecurityfeatures(numOfSecurityFeatures);
				tempListing.setNumofstories(numOfStories);
				tempListing.setNumofwaterfrontfeatures(numOfWaterfrontFeatures);
				tempListing.setNumofwindowfeatures(numOfWindowFeatures);
				tempListing.setNumpricechanges(numPriceChanges);
				tempListing.setParkingspaces(parkingSpaces);
				tempListing.setPropertytaxrate(propertyTaxRate);
				tempListing.setYearbuilt(yearBuilt);
				tempListing.setZipcode(zipcode);
				tempListing.setZipId(zipId);
				
			
				
				//listingList.add(tempListing);
			}
		} catch (SQLException e) {
			System.out.println("Issue with getAllClients");
			//ActivityLogger.debug("ClientDao: getAllClients", "Connection is Null "  + e.getMessage());
			//System.out.println(e);

		} finally {
			DatabaseHelper.closeQuietly(preparedStatement);
			DatabaseHelper.closeQuietly(connection);
			
		}
		
		return tempListing;
	}

}
