package com.sfu.object;

public class Listing {	
	private int zipcode;
	private double latitude;
	private double longitude;
	private double propertyTaxRate;
	private int garageSpaces;
	private int parkingSpaces;
	private int yearBuilt;
	private double latestPrice;
	private int numPriceChanges;
	private int latest_salemonth;
	private int latest_saleyear;
	private int numOfPhotos;
	private int numOfAccessibilityFeatures;
	private int numOfAppliances;
	private int numOfParkingFeatures;
	private int numOfPatioAndPorchFeatures;
	private int numOfSecurityFeatures;
	private int numOfWaterfrontFeatures;
	private int numOfWindowFeatures;
	private int numOfCommunityFeatures;
	private double lotSizeSqFt;
	private double livingAreaSqFt;
	private int numOfPrimarySchools;
	private int numOfElementarySchools;
	private int numOfMiddleSchools;
	private int numOfHighSchools;
	private double avgSchoolDistance;
	private double avgSchoolRating;
	private int avgSchoolSize;
	private int MedianStudentsPerTeacher;
	private double numOfBathrooms;
	private int numOfBedrooms;
	private int numOfStories;
	private int zipId;
	
	
	private String streetAddress;
	private String description;
	private String hasAssociation;
	private String hasCooling;
	private String hasGarage;
	private String hasHeating;
	private String hasSpa;
	private String hasView;	
	private String homeType;
	private String latestSaledate;
	private String latestPriceSource;
	private String city;
	private String homeImage;
	private String image;
	
	
	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getHomeImage() {
		return homeImage;
	}

	public void setHomeImage(String homeImage) {
		this.homeImage = homeImage;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getHasAssociation() {
		return hasAssociation;
	}

	public void setHasAssociation(String hasAssociation) {
		this.hasAssociation = hasAssociation;
	}

	public String getHasCooling() {
		return hasCooling;
	}

	public void setHasCooling(String hasCooling) {
		this.hasCooling = hasCooling;
	}

	public String getHasGarage() {
		return hasGarage;
	}

	public void setHasGarage(String hasGarage) {
		this.hasGarage = hasGarage;
	}

	public String getHasHeating() {
		return hasHeating;
	}

	public void setHasHeating(String hasHeating) {
		this.hasHeating = hasHeating;
	}

	public String getHasSpa() {
		return hasSpa;
	}

	public void setHasSpa(String hasSpa) {
		this.hasSpa = hasSpa;
	}

	public String getHasView() {
		return hasView;
	}

	public void setHasView(String hasView) {
		this.hasView = hasView;
	}

	public String getHomeType() {
		return homeType;
	}

	public void setHomeType(String homeType) {
		this.homeType = homeType;
	}

	public String getLatestSaledate() {
		return latestSaledate;
	}

	public void setLatestSaledate(String latestSaledate) {
		this.latestSaledate = latestSaledate;
	}

	public String getLatestPriceSource() {
		return latestPriceSource;
	}

	public void setLatestPriceSource(String latestPriceSource) {
		this.latestPriceSource = latestPriceSource;
	}

	
	
	
	

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getZipId() {
		return zipId;
	}

	public void setZipId(int zipId) {
		this.zipId = zipId;
	}

	public int getZipcode(){
		return zipcode;
	}

	public void setZipcode(int zipcode){
		this.zipcode=zipcode;
	}

	public double getLatitude(){
		return latitude;
	}

	public void setLatitude(double latitude){
		this.latitude=latitude;
	}

	public double getLongitude(){
		return longitude;
	}

	public void setLongitude(double longitude){
		this.longitude=longitude;
	}

	public double getPropertytaxrate(){
		return propertyTaxRate;
	}

	public void setPropertytaxrate(double propertyTaxRate){
		this.propertyTaxRate=propertyTaxRate;
	}

	public int getGaragespaces(){
		return garageSpaces;
	}

	public void setGaragespaces(int garageSpaces){
		this.garageSpaces=garageSpaces;
	}

	public int getParkingspaces(){
		return parkingSpaces;
	}

	public void setParkingspaces(int parkingSpaces){
		this.parkingSpaces=parkingSpaces;
	}

	public int getYearbuilt(){
		return yearBuilt;
	}

	public void setYearbuilt(int yearBuilt){
		this.yearBuilt=yearBuilt;
	}

	public double getLatestprice(){
		return latestPrice;
	}

	public void setLatestprice(double latestPrice){
		this.latestPrice=latestPrice;
	}

	public int getNumpricechanges(){
		return numPriceChanges;
	}

	public void setNumpricechanges(int numPriceChanges){
		this.numPriceChanges=numPriceChanges;
	}

	public int getLatest_salemonth(){
		return latest_salemonth;
	}

	public void setLatest_salemonth(int latest_salemonth){
		this.latest_salemonth=latest_salemonth;
	}

	public int getLatest_saleyear(){
		return latest_saleyear;
	}

	public void setLatest_saleyear(int latest_saleyear){
		this.latest_saleyear=latest_saleyear;
	}

	public int getNumofphotos(){
		return numOfPhotos;
	}

	public void setNumofphotos(int numOfPhotos){
		this.numOfPhotos=numOfPhotos;
	}

	public int getNumofaccessibilityfeatures(){
		return numOfAccessibilityFeatures;
	}

	public void setNumofaccessibilityfeatures(int numOfAccessibilityFeatures){
		this.numOfAccessibilityFeatures=numOfAccessibilityFeatures;
	}

	public int getNumofappliances(){
		return numOfAppliances;
	}

	public void setNumofappliances(int numOfAppliances){
		this.numOfAppliances=numOfAppliances;
	}

	public int getNumofparkingfeatures(){
		return numOfParkingFeatures;
	}

	public void setNumofparkingfeatures(int numOfParkingFeatures){
		this.numOfParkingFeatures=numOfParkingFeatures;
	}

	public int getNumofpatioandporchfeatures(){
		return numOfPatioAndPorchFeatures;
	}

	public void setNumofpatioandporchfeatures(int numOfPatioAndPorchFeatures){
		this.numOfPatioAndPorchFeatures=numOfPatioAndPorchFeatures;
	}

	public int getNumofsecurityfeatures(){
		return numOfSecurityFeatures;
	}

	public void setNumofsecurityfeatures(int numOfSecurityFeatures){
		this.numOfSecurityFeatures=numOfSecurityFeatures;
	}

	public int getNumofwaterfrontfeatures(){
		return numOfWaterfrontFeatures;
	}

	public void setNumofwaterfrontfeatures(int numOfWaterfrontFeatures){
		this.numOfWaterfrontFeatures=numOfWaterfrontFeatures;
	}

	public int getNumofwindowfeatures(){
		return numOfWindowFeatures;
	}

	public void setNumofwindowfeatures(int numOfWindowFeatures){
		this.numOfWindowFeatures=numOfWindowFeatures;
	}

	public int getNumofcommunityfeatures(){
		return numOfCommunityFeatures;
	}

	public void setNumofcommunityfeatures(int numOfCommunityFeatures){
		this.numOfCommunityFeatures=numOfCommunityFeatures;
	}

	public double getLotsizesqft(){
		return lotSizeSqFt;
	}

	public void setLotsizesqft(double lotSizeSqFt){
		this.lotSizeSqFt=lotSizeSqFt;
	}

	public double getLivingareasqft(){
		return livingAreaSqFt;
	}

	public void setLivingareasqft(double livingAreaSqFt){
		this.livingAreaSqFt=livingAreaSqFt;
	}

	public int getNumofprimaryschools(){
		return numOfPrimarySchools;
	}

	public void setNumofprimaryschools(int numOfPrimarySchools){
		this.numOfPrimarySchools=numOfPrimarySchools;
	}

	public int getNumofelementaryschools(){
		return numOfElementarySchools;
	}

	public void setNumofelementaryschools(int numOfElementarySchools){
		this.numOfElementarySchools=numOfElementarySchools;
	}

	public int getNumofmiddleschools(){
		return numOfMiddleSchools;
	}

	public void setNumofmiddleschools(int numOfMiddleSchools){
		this.numOfMiddleSchools=numOfMiddleSchools;
	}

	public int getNumofhighschools(){
		return numOfHighSchools;
	}

	public void setNumofhighschools(int numOfHighSchools){
		this.numOfHighSchools=numOfHighSchools;
	}

	public double getAvgschooldistance(){
		return avgSchoolDistance;
	}

	public void setAvgschooldistance(double avgSchoolDistance){
		this.avgSchoolDistance=avgSchoolDistance;
	}

	public double getAvgschoolrating(){
		return avgSchoolRating;
	}

	public void setAvgschoolrating(double avgSchoolRating){
		this.avgSchoolRating=avgSchoolRating;
	}

	public int getAvgschoolsize(){
		return avgSchoolSize;
	}

	public void setAvgschoolsize(int avgSchoolSize){
		this.avgSchoolSize=avgSchoolSize;
	}

	public int getMedianstudentsperteacher(){
		return MedianStudentsPerTeacher;
	}

	public void setMedianstudentsperteacher(int MedianStudentsPerTeacher){
		this.MedianStudentsPerTeacher=MedianStudentsPerTeacher;
	}

	public double getNumofbathrooms(){
		return numOfBathrooms;
	}

	public void setNumofbathrooms(double numOfBathrooms){
		this.numOfBathrooms=numOfBathrooms;
	}

	public int getNumofbedrooms(){
		return numOfBedrooms;
	}

	public void setNumofbedrooms(int numOfBedrooms){
		this.numOfBedrooms=numOfBedrooms;
	}

	public int getNumofstories(){
		return numOfStories;
	}

	public void setNumofstories(int numOfStories){
		this.numOfStories=numOfStories;
	}
}
